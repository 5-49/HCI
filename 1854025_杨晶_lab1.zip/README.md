初始化界面时，界面会出现短暂卡顿，稍等下就可以加载完毕。

话筒识别图标和界面将同步展示。

![图片](https://uploader.shimo.im/f/HtZg0sPGsdWSUVb6.png!thumbnail?fileGuid=WVp3xyqKYphKPD8W)

当正确发音识别对应功能时，python会调用对应功能。

打开百度网站：

![图片](https://uploader.shimo.im/f/jp7atzofFsgDs1SW.png!thumbnail?fileGuid=WVp3xyqKYphKPD8W)

打开记事本：

![图片](https://uploader.shimo.im/f/5u4c7adF9wQB3KPY.png!thumbnail?fileGuid=WVp3xyqKYphKPD8W)

